#include "uart_cli.h"
#include "pico/stdlib.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#define CLI_BUFFER_SIZE 256

static char command_buffer[CLI_BUFFER_SIZE];
static uint16_t buffer_pos = 0;
static bool command_ready = false;

void uart_cli_init(void) {
    // Note: stdio is already initialized by stdio_init_all() in main
    // We just need to initialize our buffers

    // Initialize buffer
    memset(command_buffer, 0, CLI_BUFFER_SIZE);
    buffer_pos = 0;
    command_ready = false;

    // Send welcome message
    printf("\r\n");
    printf("=================================\r\n");
    printf("  Raiden Pico - Fault Injection\r\n");
    printf("  C/C++ Edition\r\n");
    printf("=================================\r\n");
    printf("> ");
    fflush(stdout);
}

void uart_cli_send(const char *str) {
    printf("%s", str);
    fflush(stdout);
}

void uart_cli_printf(const char *format, ...) {
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    fflush(stdout);
}

void uart_cli_process(void) {
    // Check if command is already ready (not yet processed)
    if (command_ready) {
        return;
    }

    // Read all available characters using stdio (works with both USB and UART)
    int c;
    while ((c = getchar_timeout_us(0)) != PICO_ERROR_TIMEOUT) {

        // Handle special characters
        if (c == '\r' || c == '\n') {
            // End of command
            if (buffer_pos > 0) {
                command_buffer[buffer_pos] = '\0';
                command_ready = true;
                uart_cli_send("\r\n");
            } else {
                // Empty line, just show prompt
                uart_cli_send("\r\n> ");
            }
            return;
        } else if (c == '\b' || c == 127) {
            // Backspace or DEL
            if (buffer_pos > 0) {
                buffer_pos--;
                command_buffer[buffer_pos] = '\0';
                // Echo backspace sequence
                uart_cli_send("\b \b");
            }
        } else if (c == 3) {
            // Ctrl+C - clear buffer
            buffer_pos = 0;
            command_buffer[0] = '\0';
            uart_cli_send("^C\r\n> ");
        } else if (c >= 32 && c < 127) {
            // Printable character
            if (buffer_pos < CLI_BUFFER_SIZE - 1) {
                command_buffer[buffer_pos++] = (char)c;
                command_buffer[buffer_pos] = '\0';
                // Echo character
                putchar(c);
                fflush(stdout);
            }
        }
    }
}

bool uart_cli_command_ready(void) {
    return command_ready;
}

const char* uart_cli_get_command(void) {
    return command_buffer;
}

void uart_cli_clear_command(void) {
    memset(command_buffer, 0, CLI_BUFFER_SIZE);
    buffer_pos = 0;
    command_ready = false;
    uart_cli_send("> ");
}
