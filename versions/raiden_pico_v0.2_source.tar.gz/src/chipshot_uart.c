#include "config.h"
#include "uart_cli.h"
#include "hardware/uart.h"
#include "hardware/gpio.h"
#include <string.h>
#include <stdio.h>

// ChipShouter UART configuration (use UART0 on GP0/GP1)
#define CHIPSHOT_UART_ID uart0
#define CHIPSHOT_UART_BAUD 115200
#define CHIPSHOT_TX_PIN 0
#define CHIPSHOT_RX_PIN 1

// Response buffer
#define RESPONSE_BUFFER_SIZE 256
static char response_buffer[RESPONSE_BUFFER_SIZE];
static uint16_t response_pos = 0;
static bool response_ready = false;

// ChipShouter state
static bool chipshot_armed = false;

void chipshot_uart_init(void) {
    // Initialize UART for ChipShouter
    uart_init(CHIPSHOT_UART_ID, CHIPSHOT_UART_BAUD);
    gpio_set_function(CHIPSHOT_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(CHIPSHOT_RX_PIN, GPIO_FUNC_UART);

    // Enable FIFO
    uart_set_fifo_enabled(CHIPSHOT_UART_ID, true);

    // Clear response buffer
    memset(response_buffer, 0, RESPONSE_BUFFER_SIZE);
    response_pos = 0;
    response_ready = false;

    chipshot_armed = false;
}

void chipshot_uart_send(const char *data) {
    uart_puts(CHIPSHOT_UART_ID, data);
}

void chipshot_uart_process(void) {
    // Read incoming data from ChipShouter
    while (uart_is_readable(CHIPSHOT_UART_ID)) {
        char c = uart_getc(CHIPSHOT_UART_ID);

        if (c == '\r' || c == '\n') {
            if (response_pos > 0) {
                response_buffer[response_pos] = '\0';
                response_ready = true;
                return;
            }
        } else if (response_pos < RESPONSE_BUFFER_SIZE - 1) {
            response_buffer[response_pos++] = c;
        }
    }
}

bool chipshot_uart_response_ready(void) {
    return response_ready;
}

const char* chipshot_uart_get_response(void) {
    return response_buffer;
}

void chipshot_uart_clear_response(void) {
    memset(response_buffer, 0, RESPONSE_BUFFER_SIZE);
    response_pos = 0;
    response_ready = false;
}

void chipshot_arm(void) {
    chipshot_uart_send("arm\r\n");
    chipshot_armed = true;
}

void chipshot_disarm(void) {
    chipshot_uart_send("disarm\r\n");
    chipshot_armed = false;
}

void chipshot_fire(void) {
    chipshot_uart_send("trigger\r\n");
}

void chipshot_set_voltage(uint32_t voltage) {
    char cmd[32];
    snprintf(cmd, sizeof(cmd), "voltage %u\r\n", voltage);
    chipshot_uart_send(cmd);
}

void chipshot_set_pulse(uint32_t pulse_us) {
    char cmd[32];
    snprintf(cmd, sizeof(cmd), "pulse %u\r\n", pulse_us);
    chipshot_uart_send(cmd);
}

void chipshot_get_status(void) {
    chipshot_uart_send("status\r\n");
}

bool chipshot_is_armed(void) {
    return chipshot_armed;
}
