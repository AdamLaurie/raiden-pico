#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/sync.h"

int main() {
    stdio_init_all();
    sleep_ms(2000);
    
    printf("\n=== RP2350 PIO IRQ Debug ===\n");
    printf("PIO0 address: %p\n", pio0);
    printf("IRQ_FORCE register address: %p\n", &pio0->irq_force);
    printf("IRQ register address: %p\n", &pio0->irq);
    
    printf("\nInitial IRQ state: 0x%08x\n", pio0->irq);
    printf("Initial IRQ_FORCE: 0x%08x\n", pio0->irq_force);
    
    printf("\nSetting IRQ flag 5 using direct write...\n");
    pio0->irq_force = (1u << 5);
    sleep_ms(10);
    printf("IRQ after force: 0x%08x\n", pio0->irq);
    
    printf("\nClearing IRQ...\n");
    pio0->irq = 0xFF;  // Clear all
    sleep_ms(10);
    printf("IRQ after clear: 0x%08x\n", pio0->irq);
    
    printf("\nSetting IRQ flag 5 using hw_set_bits...\n");
    hw_set_bits(&pio0->irq_force, 1u << 5);
    sleep_ms(10);
    printf("IRQ after hw_set_bits: 0x%08x\n", pio0->irq);
    
    printf("\nTest complete\n");
    
    while(1) tight_loop_contents();
    return 0;
}
