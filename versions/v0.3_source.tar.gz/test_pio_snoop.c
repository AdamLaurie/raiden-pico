#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include <stdio.h>

// UART RX snoop PIO program - directly from example
const uint16_t uart_rx_snoop_program_instructions[] = {
    //     .wrap_target
    0x2020, //  0: wait   0 pin, 0
    0xe02b, //  1: set    x, 11
    0x0042, //  2: jmp    x--, 2
    0xe027, //  3: set    x, 7
    0x4701, //  4: in     pins, 1             [7]
    0x0044, //  5: jmp    x--, 4
    0xa007, //  6: nop                        [7]
    0x8020, //  7: push   block
    //     .wrap
};

const struct pio_program uart_rx_snoop_program = {
    .instructions = uart_rx_snoop_program_instructions,
    .length = 8,
    .origin = -1,
};

static inline pio_sm_config uart_rx_snoop_program_get_default_config(uint offset) {
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + 0, offset + 7);
    return c;
}

// Choose your pins/uart
#define UART_ID       uart1
#define UART_TX_PIN   4    // GP4 = Target UART TX
#define UART_RX_PIN   5    // GP5 = Target UART RX
#define BAUD          115200

int main() {
    stdio_init_all();
    sleep_ms(2000);

    printf("\n\n=== PIO UART Snooping Test ===\n");
    printf("This will snoop GP5 (Target UART RX) while hardware UART receives\n\n");

    // --- Hardware UART as usual ---
    uart_init(UART_ID, BAUD);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
    printf("✓ Hardware UART1 initialized on GP%d (TX), GP%d (RX) at %d baud\n",
           UART_TX_PIN, UART_RX_PIN, BAUD);

    // --- PIO sniffer on the SAME RX pin ---
    PIO pio = pio0;
    uint sm = pio_claim_unused_sm(pio, true);
    uint offset = pio_add_program(pio, &uart_rx_snoop_program);
    printf("✓ PIO program loaded at offset %d, using SM %d\n", offset, sm);

    pio_sm_config c = uart_rx_snoop_program_get_default_config(offset);

    // IMPORTANT: tell the SM which pad to sample.
    sm_config_set_in_pins(&c, UART_RX_PIN);   // PIO reads this GPIO
    sm_config_set_jmp_pin(&c, UART_RX_PIN);   // used by 'wait pin' and 'jmp pin'
    printf("✓ PIO configured to read GP%d (same as UART RX)\n", UART_RX_PIN);

    // Shift LSB-first, autopush after 8 bits (one byte)
    sm_config_set_in_shift(&c, true, true, 8);

    // Clock at 8x baud
    float pio_clk = (float)clock_get_hz(clk_sys);
    float div = pio_clk / (BAUD * 8.0f);
    sm_config_set_clkdiv(&c, div);
    printf("✓ PIO clock divider: %.2f (system clock: %.0f Hz, 8x baud: %.0f Hz)\n",
           div, pio_clk, BAUD * 8.0f);

    // Note: we DO NOT switch the pin to GPIO_FUNC_PIOx. It remains GPIO_FUNC_UART.
    // PIO can still read it because pin inputs are fanned out to all consumers.
    printf("✓ GP%d remains assigned to UART (PIO snoops via input fanout)\n", UART_RX_PIN);

    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
    printf("✓ PIO state machine started\n\n");

    printf("Waiting for UART data on GP%d...\n", UART_RX_PIN);
    printf("Send data to the target UART and it will appear below:\n");
    printf("---------------------------------------------------\n");

    uint32_t snoop_count = 0;
    uint32_t uart_count = 0;

    while (true) {
        // Read snooped bytes from the PIO RX FIFO (non-intrusive)
        if (!pio_sm_is_rx_fifo_empty(pio, sm)) {
            uint32_t raw = pio_sm_get(pio, sm);
            uint8_t b = (uint8_t)raw;
            snoop_count++;
            printf("PIO SNOOP [%4d]: 0x%02X", snoop_count, b);
            if (b >= 32 && b < 127) {
                printf(" '%c'", b);
            }
            printf("\n");
        }

        // Meanwhile, your normal UART traffic continues:
        if (uart_is_readable(UART_ID)) {
            uint8_t b = uart_getc(UART_ID);
            uart_count++;
            printf("UART READ [%4d]: 0x%02X", uart_count, b);
            if (b >= 32 && b < 127) {
                printf(" '%c'", b);
            }
            printf("\n");
        }

        sleep_ms(10);
    }
}
