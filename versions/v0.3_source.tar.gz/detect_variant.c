// Simple program to detect RP2350A vs RP2350B variant
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/regs/sysinfo.h"
#include "hardware/structs/sysinfo.h"

int main() {
    stdio_init_all();

    // Don't wait for USB serial, just print immediately
    sleep_ms(2000);  // Small delay for USB enumeration

    printf("\n=== RP2350 Variant Detection ===\n\n");

    // Read chip ID and revision
    uint32_t chip_id = sysinfo_hw->chip_id;
    uint32_t revision = sysinfo_hw->gitref_rp2350;
    uint32_t platform = sysinfo_hw->platform;

    printf("Chip ID: 0x%08x\n", chip_id);
    printf("Revision: 0x%08x\n", revision);
    printf("Platform: 0x%08x\n", platform);

    // The chip ID for RP2350 should be 0x0003
    // Revision bit 28 indicates A (0) or B (1) stepping
    if ((chip_id & 0xFFFF) == 0x0003) {
        printf("\nDetected: RP2350");
        if (revision & (1 << 28)) {
            printf("B (Stepping B1)\n");
            printf("\n*** WARNING: RP2350B has known PIO issues! ***\n");
            printf("PIO cannot read pins assigned to other functions.\n");
            printf("This affects UART snooping capability.\n");
        } else {
            printf("A (Stepping A2)\n");
            printf("\nRP2350A - PIO should work normally.\n");
        }
    } else {
        printf("\nUnknown chip ID: 0x%04x\n", chip_id & 0xFFFF);
    }

    printf("\n=== Detection Complete ===\n");

    // Keep printing the variant info every 2 seconds
    while (1) {
        sleep_ms(2000);
        if ((chip_id & 0xFFFF) == 0x0003) {
            if (revision & (1 << 28)) {
                printf("Variant: RP2350B (PIO issues present)\n");
            } else {
                printf("Variant: RP2350A (PIO should work)\n");
            }
        }
    }

    return 0;
}