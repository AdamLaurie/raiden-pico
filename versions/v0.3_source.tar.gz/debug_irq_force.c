#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "glitch.pio.h"

int main() {
    stdio_init_all();
    sleep_ms(3000);
    
    printf("\n=== RP2350 PIO IRQ_FORCE Debug ===\n\n");
    
    // Show register addresses
    printf("PIO0 base: 0x%08x\n", (uint32_t)pio0);
    printf("IRQ register: 0x%08x (offset 0x%03x)\n", (uint32_t)&pio0->irq, (uint32_t)&pio0->irq - (uint32_t)pio0);
    printf("IRQ_FORCE register: 0x%08x (offset 0x%03x)\n\n", (uint32_t)&pio0->irq_force, (uint32_t)&pio0->irq_force - (uint32_t)pio0);
    
    // Load the pulse generator program
    uint offset = pio_add_program(pio0, &pulse_generator_program);
    printf("Loaded pulse_generator at offset %d\n", offset);
    
    // Configure SM1 with the program
    pio_sm_config c = pulse_generator_program_get_default_config(offset);
    sm_config_set_set_pins(&c, 2, 1);  // Output on GP2
    sm_config_set_clkdiv(&c, 1.0);
    
    pio_gpio_init(pio0, 2);
    pio_sm_set_consecutive_pindirs(pio0, 1, 2, 1, true);
    pio_sm_init(pio0, 1, offset, &c);
    
    // Pre-load FIFO with dummy timing values
    pio_sm_put_blocking(pio0, 1, 100);  // Pause
    pio_sm_put_blocking(pio0, 1, 1000); // Width  
    pio_sm_put_blocking(pio0, 1, 100);  // Gap
    
    // Enable SM1
    pio_sm_set_enabled(pio0, 1, true);
    printf("SM1 enabled and waiting on 'wait 1 irq 5'\n\n");
    
    sleep_ms(100);
    
    // Test 1: Direct write to IRQ_FORCE
    printf("Test 1: Direct write pio0->irq_force = (1 << 5)\n");
    printf("  Before: IRQ=0x%02x\n", pio0->irq);
    pio0->irq_force = (1u << 5);
    sleep_ms(10);
    printf("  After:  IRQ=0x%02x\n", pio0->irq);
    printf("  Did SM1 advance? Check GP2 output\n\n");
    
    sleep_ms(1000);
    
    // Clear and reload
    pio_sm_set_enabled(pio0, 1, false);
    pio_sm_clear_fifos(pio0, 1);
    pio_sm_restart(pio0, 1);
    pio_sm_put_blocking(pio0, 1, 100);
    pio_sm_put_blocking(pio0, 1, 1000);
    pio_sm_put_blocking(pio0, 1, 100);
    pio_sm_set_enabled(pio0, 1, true);
    sleep_ms(100);
    
    // Test 2: Write-only alias
    printf("Test 2: Using hw_set_bits\n");
    printf("  Before: IRQ=0x%02x\n", pio0->irq);
    hw_set_bits(&pio0->irq_force, 1u << 5);
    sleep_ms(10);
    printf("  After:  IRQ=0x%02x\n", pio0->irq);
    printf("  Did SM1 advance?\n\n");
    
    sleep_ms(1000);
    
    // Test 3: Using pio_sm_exec with irq set
    pio_sm_set_enabled(pio0, 1, false);
    pio_sm_clear_fifos(pio0, 1);
    pio_sm_restart(pio0, 1);
    pio_sm_put_blocking(pio0, 1, 100);
    pio_sm_put_blocking(pio0, 1, 1000);
    pio_sm_put_blocking(pio0, 1, 100);
    pio_sm_set_enabled(pio0, 1, true);
    sleep_ms(100);
    
    printf("Test 3: Using pio_sm_exec with pio_encode_irq_set\n");
    printf("  Before: IRQ=0x%02x\n", pio0->irq);
    pio_sm_exec(pio0, 0, pio_encode_irq_set(false, 5));
    sleep_ms(10);
    printf("  After:  IRQ=0x%02x\n", pio0->irq);
    printf("  Did SM1 advance?\n\n");
    
    printf("=== Tests complete ===\n");
    printf("Press any key to exit\n");
    
    getchar();
    return 0;
}
