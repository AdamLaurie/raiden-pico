#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/uart.h"
#include <stdio.h>

// Ultra-simple PIO: wait for GP5 to go low, then fire IRQ
const uint16_t test_gp5_program_instructions[] = {
    0xa022, //  0: mov    x, pins          ; Read all pins
    0x8020, //  1: push   block           ; Push to FIFO for debugging
    0x2085, //  2: wait   0 gpio, 5        ; Wait for GP5 low
    0xc003, //  3: irq    wait 3           ; Fire IRQ 3
};

const struct pio_program test_gp5_program = {
    .instructions = test_gp5_program_instructions,
    .length = 4,
    .origin = -1,
};

volatile uint32_t irq_count = 0;

void pio_irq_handler() {
    if (pio_interrupt_get(pio0, 3)) {
        pio_interrupt_clear(pio0, 3);
        irq_count++;
        gpio_put(PICO_DEFAULT_LED_PIN, !gpio_get(PICO_DEFAULT_LED_PIN));
    }
}

int main() {
    stdio_init_all();
    sleep_ms(3000);

    printf("\n\n=== PIO GP5 Detection Test ===\n");
    printf("Testing if PIO can see GP5 transitions\n\n");

    // Setup LED
    gpio_init(PICO_DEFAULT_LED_PIN);
    gpio_set_dir(PICO_DEFAULT_LED_PIN, GPIO_OUT);
    gpio_put(PICO_DEFAULT_LED_PIN, 0);

    // Setup UART1 on GP4/GP5
    uart_init(uart1, 115200);
    gpio_set_function(4, GPIO_FUNC_UART);
    gpio_set_function(5, GPIO_FUNC_UART);
    printf("✓ UART1 configured on GP4/GP5 at 115200 baud\n");
    printf("  GP5 is assigned to UART function\n\n");

    // Setup PIO to monitor GP5
    PIO pio = pio0;
    uint sm = 0;
    uint offset = pio_add_program(pio, &test_gp5_program);

    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset, offset + 3);

    // Enable autopush for debugging
    sm_config_set_in_shift(&c, false, true, 32);

    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);

    printf("✓ PIO state machine started\n");
    printf("  Monitoring GP5 with 'wait 0 gpio 5'\n");
    printf("  LED will toggle when GP5 goes low\n");
    printf("  IRQ 3 will fire\n\n");

    // Setup IRQ handler
    pio_set_irq0_source_enabled(pio, pis_interrupt3, true);
    irq_set_exclusive_handler(PIO0_IRQ_0, pio_irq_handler);
    irq_set_enabled(PIO0_IRQ_0, true);

    printf("✓ IRQ handler installed\n\n");
    printf("Send data to GP5 (Target UART RX) and watch:\n");
    printf("  1. LED should toggle\n");
    printf("  2. IRQ count should increment\n");
    printf("  3. Pin states will be pushed to FIFO\n");
    printf("---------------------------------------------------\n\n");

    uint32_t last_count = 0;
    while (true) {
        // Check if IRQ fired
        if (irq_count != last_count) {
            printf("IRQ FIRED! Count: %d\n", irq_count);
            last_count = irq_count;
        }

        // Check FIFO for pin readings
        if (!pio_sm_is_rx_fifo_empty(pio, sm)) {
            uint32_t pins = pio_sm_get(pio, sm);
            printf("PIO read pins: 0x%08X (GP5 = %d)\n", pins, (pins >> 5) & 1);
        }

        // Check UART
        if (uart_is_readable(uart1)) {
            uint8_t b = uart_getc(uart1);
            printf("UART received: 0x%02X\n", b);
        }

        sleep_ms(100);
    }
}
