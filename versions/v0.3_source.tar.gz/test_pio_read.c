// Simple test to verify PIO can read GP28
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

// Simple PIO program to continuously read a pin and push to FIFO
const uint16_t pin_reader_program[] = {
    0x4001,  // in pins, 1    - Read 1 bit from pin into ISR
    0x8020,  // push block    - Push ISR to FIFO when full (32 bits)
};

int main() {
    stdio_init_all();
    sleep_ms(2000);

    printf("\n=== PIO Pin Reader Test ===\n");
    printf("Testing if PIO can read GP28\n");
    printf("Jumper GP5->GP28 should be connected\n\n");

    PIO pio = pio0;
    uint sm = 0;
    uint offset = pio_add_program(pio, (pio_program_t){
        .instructions = pin_reader_program,
        .length = 2,
        .origin = -1
    });

    // Configure GP28 for PIO
    pio_gpio_init(pio, 28);
    pio_sm_set_consecutive_pindirs(pio, sm, 28, 1, false); // Input

    // Configure state machine
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_in_pins(&c, 28);
    sm_config_set_in_shift(&c, false, true, 32); // Shift left, autopush at 32
    sm_config_set_clkdiv(&c, 1000); // Slow it down for testing

    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);

    printf("PIO reading GP28, displaying pin state:\n");

    int count = 0;
    while (count < 100) {
        if (!pio_sm_is_rx_fifo_empty(pio, sm)) {
            uint32_t data = pio_sm_get(pio, sm);
            printf("Read: 0x%08x (", data);

            // Show binary representation
            for (int i = 31; i >= 0; i--) {
                printf("%d", (data >> i) & 1);
                if (i % 8 == 0 && i > 0) printf(" ");
            }
            printf(")\n");

            count++;
        }
        sleep_ms(100);
    }

    printf("\nTest complete\n");
    return 0;
}